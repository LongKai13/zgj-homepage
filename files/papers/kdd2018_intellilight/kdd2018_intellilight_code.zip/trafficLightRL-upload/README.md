# IntelliLight



This project has been published as the following conference paper:

> Hua Wei\*, Guanjie Zheng\*, Huaxiu Yao, Zhenhui Li, IntelliLight: A Reinforcement Learning Approach for Intelligent Trafficc Light Control, in Proceedings of the 2018 ACM SIGKDD International Conference on Knowledge Discovery and Data Mining (KDD'18), London, UK, August 2018. 
>
> (\*Co-First author.)



The full paper and demo can be found at the author's website.



This project proposes a reinforcement learning based intelligent traffic light control system. Simply run the runexp.py to run the experiment. Please change the parameters in conf/ folder and runexp.py correspondingly if needed.



The files are functioning like this:

- runexp.py

  Load the experiment setting, and call traffic_light_agent.

- traffic_light_dqn.py

  Simulate the reinforcement learning agent. This file simulates the timeline, get current state from sumo_agent, get current state from sumo_agent and call the agent to make decision.

- sumo_agent.py

  Interact with map_computor to get state, reward from the map_computor, and convey action to map_computor.

- map_computor.py

  Read data from SUMO and operate SUMO.

- agent.py

  Abstract class of agent.

- network_agent.py

  Abstract class of neural network based agent.

- deeplight_agent.py

  Class of our method.

- conf/

  Configuration files.

- data/

  Traffic flow files.