function install(command)
%	function install(command)
%
% call "install" to compile functions on demand (when required)
% or "install('force')"	to compile all functions (even when binaries already exist)
% 
% copyright by Kilian Q. Weinberger, Sept. 2012

if nargin<1,command='';end;
force=strcmp(command,'force');
force=false;
if nargin==1, 
	if strcmp(command,'force'), force=true;
	else 
		fprintf('Command %s unknown.\n',command);
		return;
	end;
end;

addpath(pwd);
setpaths
cd mexfunctions
fprintf('Compiling all mex functions ... \n\n');

comperror=false;
% compile helperfunctions
comperror=comperror || compile('SODWm.c',force);

addpath(pwd);
cd ..


if 	comperror,
	fprintf('\n\nLooks like you had some compilation errors.\n');
	fprintf('There is a good chance it still works with the pre-compiled binaries that are already included in the path.\nGood luck!\n')
else
	fprintf('\n\nNo compilation errors. Everything should run smoothly.\n')
	if ~force,
 	 fprintf('(In case of errors you can force recompilation with "install(''force'')".)\n')
   end;
   fprintf('Run "demo" to try out MLKR.\nGood luck!\n-Kilian\n');
end;



function comperror=compile(filename,force)
	
	comperror=false;
	s=regexp(filename,'\.','split');
	fprintf('%s...',filename)
	if ~force && (exist(['./' s{1}])==3 || exist(['binaries/' s{1}])==3),
		fprintf('[binary exists]\n');
		return;
	end;
	try
	    mex(filename)
		fprintf('[compiled]\n');
	catch
		fprintf('[ERROR]\n');
        fprintf(lasterr);
        fprintf('\n');
		comperror=true;
	end;    
	